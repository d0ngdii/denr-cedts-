<?php
// Database connection
$db = require_once 'db_queries/db_connection.php';

// Fetch documents from the database
function getDocuments($db)
{
    $result = $db->query("SELECT sender, document_type, subject, date_received, status, appointment_type FROM documents");
    $documents = [];

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $documents[] = $row;
        }
    }

    return $documents;
}

// Fetch documents for initial load
$documents = getDocuments($db);
$db->close();
?>

<!-- Document Table -->
<div id="content">
    <div class="dashboard-overlay">Documents</div>
    <div class="dash"></div>
    <div class="add-document">
        <button class="document-add-btn" onclick="docOpenModal()">
            + Submit Document
        </button>
    </div>
    <div class="searchbar-document">
        <input type="text" id="documentSearchInput" class="document-search-input" placeholder="Search" />
    </div>
    <div class="table-document">
        <div class="table-container">
            <table class="document-table" id="documentTable">
                <thead>
                    <tr>
                        <th>Sender</th>
                        <th>Document Type</th>
                        <th>Subject</th>
                        <th>Date Received</th>
                        <th>Status</th>
                        <th>Appointment</th>
                    </tr>
                </thead>
                <tbody id="documentTableBody">
                    <?php foreach ($documents as $document): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($document['sender']); ?></td>
                            <td><?php echo htmlspecialchars($document['document_type']); ?></td>
                            <td><?php echo htmlspecialchars($document['subject']); ?></td>
                            <td><?php echo htmlspecialchars($document['date_received']); ?></td>
                            <td><?php echo htmlspecialchars($document['status']); ?></td>
                            <td><?php echo htmlspecialchars($document['appointment_type']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Document Modal Overlay -->
<div class="document-modal-overlay" id="documentModalOverlay" onclick="docCloseModal()"></div>

<!-- Add Document Modal -->
<div class="document-modal" id="addDocumentModal">
    <h2>
        Submit Document
        <button class="document-close-btn" onclick="docCloseModal()">✖️</button>
    </h2>
    <form id="addDocumentForm" enctype="multipart/form-data">
        <div class="row">
            <div class="document-input-group">
                <input type="text" name="appointment_number" id="appointment_number" placeholder="Appointment Number" readonly />
            </div>
            <div class="document-input-group">
                <input type="text" name="sender" placeholder="Sender" required />
            </div>
            <div class="document-input-group">
                <input type="email" name="email" placeholder="Email" required />
            </div>
        </div>
        <div class="row">
            <div class="document-input-group">
                <input type="tel" name="contact_number" placeholder="Contact Number" required />
            </div>
            <div class="document-input-group">
                <input type="text" name="document_type" placeholder="Document Type" required />
            </div>
            <div class="document-input-group">
                <input type="text" name="purpose" placeholder="Purpose" required />
            </div>
        </div>
        <div class="row">
            <div class="document-input-group">
                <select id="paidSelect" name="paid" required>
                    <option value="" disabled selected>Paid</option>
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
            </div>
            <div class="document-input-group">
                <input type="text" name="subject" placeholder="Subject" />
            </div>
            <div class="document-input-group">
                <input type="text" id="date" name="date_received" placeholder="MM/DD/YYYY" readonly />
            </div>
        </div>
        <div class="row">
            <div class="document-input-group">
                <select id="statusSelect" name="status" required>
                    <option value="" disabled selected>Status</option>
                    <option value="Pending">Pending</option>
                    <option value="Released">Released</option>
                    <option value="Ongoing">Ongoing</option>
                    <option value="Rejected">Rejected</option>
                </select>
            </div>
            <div class="document-input-group">
                <select id="appointmentTypeSelect" name="appointment_type" required>
                    <option value="" disabled selected>Appointment Type</option>
                    <option value="Online" disabled>Online</option>
                    <option value="Walk-in">Walk-in</option>
                </select>
            </div>
            <div class="document-input-group">
                <input type="datetime-local" name="appointment_date" required />
            </div>
        </div>
        <!-- Add file input for multiple PDF uploads -->
        <div class="document-input-group">
            <input type="file" name="files[]" multiple accept=".pdf" required />
        </div>
        <button type="submit" class="document-submit-btn">Submit</button>
    </form>
</div>

<!-- Document View Pop-up Form Overlay -->
<div class="docp-popup-overlay" id="popupOverlay"></div>

<!-- Document View Pop-up Form -->
<div class="docp-popup-form" id="popupForm">
    <header>
        <img src="icons/denr_logo.png" alt="DENR Logo" class="docp-logo" />
        <h2>CENRO GUINOBATAN: ELECTRONIC DOCUMENT TRACKING SYSTEM</h2>
        <button class="docp-close-btn" onclick="docpClosePopup()">✖️</button>
    </header>

    <div class="docp-appointment-number">
        <h3 id="appointmentNumberDisplay"></h3>
        <p>Appointment Number</p>
    </div>

    <div class="docp-info-grid">
        <div class="docp-form-group">
            <label>Name of Sender:</label>
            <span id="senderName"></span>
        </div>
        <div class="docp-form-group">
            <label>Email:</label>
            <span id="senderEmail"></span>
        </div>
        <div class="docp-form-group">
            <label>Contact Number:</label>
            <span id="contactNumber"></span>
        </div>
        <div class="docp-form-group">
            <label>Status:</label>
            <span id="status"></span>
        </div>
        <div class="docp-form-group">
            <label>Document Type:</label>
            <span id="documentType"></span>
        </div>
        <div class="docp-form-group">
            <label>Purpose:</label>
            <span id="purpose"></span>
        </div>
        <div class="docp-form-group">
            <label>Paid:</label>
            <span id="paid"></span>
        </div>
        <div class="docp-form-group">
            <label>Date Received:</label>
            <span id="dateReceived"></span>
        </div>
        <div class="docp-form-group">
            <label>Appointment Date:</label>
            <span id="appointmentDate"></span>
        </div>
    </div>

    <div class="docp-attached-files">
        <h3>Attached Files:</h3>
        <div id="fileList"></div>
        <a href="#" class="docp-download-all" onclick="docpDownloadAll()">Download all</a>
    </div>

    <button class="docp-next-button" onclick="docpNextStep()">Next</button>
</div>

<!-- Confirmation of Appointment Pop-up Form Overlay -->
<div class="appointment-popup-overlay" id="appointmentPopupOverlay"></div>

<!-- Confirmation of Appointment Appointment Pop-up Form -->
<div class="appointment-popup-form" id="appointmentPopupForm">
    <div class="ap_container">
        <div class="ap_header">Accept Appointment?</div>
        <div class="ap_content">
            <p class="ap_note">Note: Please check all required documents before proceeding with payment</p>
            <div class="ap_buttons">
                <button id="proceed" onclick="proceedToOrderPayment()">PROCEED</button>
                <button id="decline" onclick="closeAppointmentPopup()">DECLINE</button>
            </div>
        </div>
    </div>
</div>


<script src="/functions/documents.js"></script>