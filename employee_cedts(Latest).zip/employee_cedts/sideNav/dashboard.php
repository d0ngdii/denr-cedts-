<?php
// Database connection
$db = require_once 'db_queries/db_connection.php';

// Function to fetch stat values from the database
function getStats($db)
{
    $queries = [
        'rejected_documents' => "SELECT COUNT(*) as count FROM documents WHERE status = 'Rejected'",
        'released_documents' => "SELECT COUNT(*) as count FROM documents WHERE status = 'Released'",
        'pending_documents' => "SELECT COUNT(*) as count FROM documents WHERE status = 'Pending'",
        'ongoing_documents' => "SELECT COUNT(*) as count FROM documents WHERE status = 'Ongoing'"
    ];

    $stats = [];

    foreach ($queries as $key => $query) {
        $result = $db->query($query);
        if ($result) {
            $row = $result->fetch_assoc();
            $stats[$key] = $row['count'];
            $result->free();
        } else {
            $stats[$key] = 0;
            // Add error logging
            error_log("Query failed: " . $db->error . " for query: " . $query);
        }
    }

    return $stats;
}

// Fetch all stat values
$stats = getStats($db);

// Output stats as JSON
echo '<script>var dashboardStats = ' . json_encode($stats) . ';</script>';

// Add debugging information
echo '<script>console.log("Dashboard Stats:", ' . json_encode($stats) . ');</script>';

$db->close();
?>

<!-- The rest of your HTML code remains the same -->
<div class="dashboard-overlay">Dashboard</div>
<div class="dash"> </div>
<div class="environmental-icons">
    <div class="env-icon">🍃</div>
    <div class="env-icon">🚗</div>
    <div class="env-icon">♻️</div>
</div>
<div class="stats-container">
    <div class="stats-row">
        <div class="stat-item">
            <div class="stat-content1">
                <div class="stat-info">
                    <h3 class="stat-title">Ongoing Documents</h3>
                    <p class="stat-subtitle">Document Tracking System</p>
                </div>
                <p class="stat-value"><?php echo $stats['ongoing_documents']; ?></p>
            </div>
        </div>
        <div class="stat-item">
            <div class="stat-content2">
                <div class="stat-info">
                    <h3 class="stat-title">Released Documents</h3>
                    <p class="stat-subtitle">Document Tracking System</p>
                </div>
                <p class="stat-value"><?php echo $stats['released_documents']; ?></p>
            </div>
        </div>
    </div>
    <div class="stats-row">
        <div class="stat-item">
            <div class="stat-content3">
                <div class="stat-info">
                    <h3 class="stat-title">Rejected Documents</h3>
                    <p class="stat-subtitle">Document Tracking System</p>
                </div>
                <p class="stat-value"><?php echo $stats['rejected_documents']; ?></p>
            </div>
        </div>
        <div class="stat-item">
            <div class="stat-content4">
                <div class="stat-info">
                    <h3 class="stat-title">Pending Documents</h3>
                    <p class="stat-subtitle">Document Tracking System</p>
                </div>
                <p class="stat-value"><?php echo $stats['pending_documents']; ?></p>
            </div>
        </div>
    </div>
</div>