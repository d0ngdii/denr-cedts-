<?php
// Database connection
$db = require_once 'db_queries/db_connection.php';

// Fetch users from the database
function getUsers($db)
{
    $result = $db->query("SELECT id, name, position, contact FROM users");
    $users = [];

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
    }

    return $users;
}

// Fetch users for initial load
$users = getUsers($db);
$db->close();
?>

<div class="dashboard-overlay">Section/Units</div>
<div class="dash"></div>
<div class="add-account-section">
    <button class="section-add-account-btn" onclick="secOpenModal()">+ ADD ACCOUNT</button>
</div>
<div class="searchbar-section">
    <input type="text" id="secsearchInput" class="section-search-input" placeholder="Search">
</div>
<div class="table-section">
    <table class="user-table" id="usertable">
        <thead>
            <tr>
                <th>ID</th>
                <th>Users</th>
                <th>Position</th>
                <th>Contact</th>
            </tr>
        </thead>
        <tbody id="userTableBody">
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['id']); ?></td>
                    <td><?php echo htmlspecialchars($user['name']); ?></td>
                    <td><?php echo htmlspecialchars($user['position']); ?></td>
                    <td><?php echo htmlspecialchars($user['contact']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Add Account Modal Overlay -->
<div class="section-modal-overlay" id="sectionModalOverlay" onclick="secCloseModal()"></div>

<!-- Add Account Modal -->
<div class="section-modal" id="addAccountModal">
    <h2>
        Sign up
        <button class="section-close-btn" onclick="secCloseModal()">✖️</button>
    </h2>
    <p>Create an account here</p>
    <form id="addAccountForm">
        <div class="section-input-group">
            <input type="text" name="fullName" placeholder="Full Name" required>
        </div>
        <div class="section-input-group">
            <input type="tel" name="mobileNumber" placeholder="Mobile Number" required>
        </div>
        <div class="section-input-group">
            <input type="email" name="email" placeholder="Email Address" required>
        </div>
        <div class="section-input-group">
            <input type="password" id="password" name="password" placeholder="Password" required>
            <span class="eye-icon" onclick="togglePassword()">👁️</span>
        </div>
        <div class="section-input-group">
            <select id="positionSelect" name="position" required>
                <option value="" disabled selected>Position</option>
                <option value="CENR Office">CENR Office</option>
                <option value="Admin UNIT">Admin Unit</option>
                <option value="Records Section">Records Section</option>
                <option value="CDS">CDS</option>
                <option value="RPS">RPS</option>
                <option value="MES">MES</option>
            </select>
        </div>
        <p style="font-size: 12px; text-align: center;">By signing up you agree with our Terms of Use</p>
        <button type="submit" class="section-submit-btn">→</button>
    </form>
</div>