<div class="track_document_container">
    <div class="track_document_left-panel">
        <div class="dashboard-overlay">Track a Document</div>
        <div class="dash"></div>
        <div class="track_document_info-grid">
            <div>Tracking Number:</div>
            <div>2024-09282</div>
            <div>Document Type:</div>
            <div>Cutting Permit</div>
            <div>Name of client:</div>
            <div>Dela Cruz, Juan Manuel</div>
            <div>Email:</div>
            <div>juan.delacruz12@gmail.com</div>
            <div>Status:</div>
            <div class="track_document_status">RELEASED</div>
            <div>Personnel:</div>
            <div>Unknown</div>
            <div>Appointment Date:</div>
            <div>May, 06 2024 11:15 AM</div>
            <div>Released Date:</div>
            <div>Not yet released</div>
            <div>ATTACHMENT:</div>
            <div>No attached document</div>
            <div>Confidential:</div>
            <div>NO</div>
            <div>Compliance Date:</div>
            <div>None</div>
            <div>Paid:</div>
            <div>YES</div>
        </div>
        <hr>
        <div class="track_document_info-grid">
            <div>ORIGIN:</div>
            <div>ADMINISTRATIVE UNIT</div>
            <div>PERSONNEL:</div>
            <div>NAME OF PERSONNEL</div>
            <div>DATE/TIME:</div>
            <div>MM/DD/YY 00:00AM</div>
            <div>END:</div>
            <div>RECORDS SECTION</div>
            <div>PERSONNEL:</div>
            <div>NAME OF PERSONNEL</div>
            <div>DATE/TIME:</div>
            <div>MM/DD/YY 00:00AM</div>
        </div>
    </div>
    <div class="track_document_right-panel">
        <h2>Document Received</h2>
        <div class="track_document_document-card">
            <h3>Admin Unit</h3>
            <div>Actions Take: Verifying Document</div>
            <div>Personnel: Unknown</div>
            <div>Forwarded to: Records Section</div>
            <div>Route Purpose: <span class="track_document_highlight">Receiving Stamp</span></div>
            <div>Date/Time: May, 06 2024 11:15 AM</div>
        </div>
        <div class="track_document_arrow-down">&#9660;</div>
        <div class="track_document_document-card">
            <h3>Records Section</h3>
            <div>Actions Take: Document Stamped</div>
            <div>Personnel: Unknown</div>
            <div>Forwarded to: CENR Office</div>
            <div>Route Purpose: <span class="track_document_highlight">Note to designated section</span></div>
            <div>Date/Time: May, 06 2024 11:15 AM</div>
        </div>
        <div class="track_document_arrow-down">&#9660;</div>
        <div class="track_document_document-card">
            <h3>CENR Office</h3>
            <div>Actions Take: Document Noted</div>
            <div>Personnel: Unknown</div>
            <div>Forwarded to: RPS Section</div>
            <div>Route Purpose: <span class="track_document_highlight">Processing of permit</span></div>
            <div>Date/Time: May, 06 2024 11:15 AM</div>
        </div>
        <div class="track_document_arrow-down">&#9660;</div>
        <div class="track_document_document-card">
            <h3>RPS</h3>
            <div>Actions Take: Processing Request</div>
            <div>Personnel: Unknown</div>
            <div>Forwarded to: N/A</div>
            <div>Route Purpose: <span class="track_document_highlight">Processing of permit</span></div>
            <div>Date/Time: May, 06 2024 11:15 AM</div>
        </div>
    </div>
</div>