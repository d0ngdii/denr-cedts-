<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document Tracking System</title>
    <link rel="stylesheet" href="designs/dashboard.css">
    <link rel="stylesheet" href="designs/section_units.css">
    <link rel="stylesheet" href="designs/documents.css">
    <link rel="stylesheet" href="designs/track_documents.css">
</head>

<body>
    <!--Responsive Header(Start)-->
    <div class="header">
        <div class="container" onclick="toggleNav(this)">
            <div class="bar1"></div>
            <div class="bar2"></div>
            <div class="bar3"></div>
        </div>
        <img src="icons/denr_logo.png" alt="DENR logo" class="logo" />
        <h1 class="title"> COMMUNAL ELECTRONIC DOCUMENT <br /> TRACKING SYSTEM (CEDTS) GUINOBATAN, ALBAY</h1>
        <div class="header-right">
            <div class="btn-container">
                <button onclick="toggleNotifications()" class="btn1">
                    <img src="icons/notif_icon.png" alt="Notifications" class="notification">
                    <span class="notification-count" id="notificationCount">0</span>
                </button>
                <!-- <div id="notificationDropdown" class="dropdown-content"></div> -->
                <button class="btn2"><img src="icons/settings_icon.png" alt="Settings" class="setting"></button>
            </div>
            <div id="current-time" class="current-time">
            </div>
        </div>
    </div>
    <!--Responsive Header(End)-->

    <!-- Notifications Table (Start) -->
    <div id="overlay" class="overlay"></div>
    <div id="notificationPopup" class="notification-popup">
        <div class="notification-header">
            <h2>Notifications</h2>
            <button class="close-btn" onclick="toggleNotifications()">&times;</button>
        </div>
        <div class="notification-actions">
            <button onclick="markAllAsRead()">Mark all as read</button>
            <button onclick="deleteSelected()">Delete selected</button>
        </div>
        <table id="notificationTable">
            <thead>
                <tr>
                    <th><input type="checkbox" id="selectAll" onclick="toggleSelectAll()"></th>
                    <th>Title</th>
                    <th>Message</th>
                    <th>Type</th>
                    <th>Received</th>
                    <th>Read?</th>
                </tr>
            </thead>
            <tbody id="notificationBody">
                <!-- Notifications will be dynamically added here -->
            </tbody>
        </table>
    </div>
    <!-- Notifications Table(End) -->

    <!--Side Navigation Bar(Start)-->
    <div id="mySidenav" class="sidenav">
        <div class="profile-section">
            <img src="icons/default_pfp.png" alt="Profile Picture" class="profile-pic">
            <div class="profile-name">ADMIN</div>
            <div class="profile-email">admin00@cedts-denr.com</div>
        </div>
        <a href="#" onclick="loadMain('dashboard')">Dashboard</a>
        <a href="#" onclick="loadMain('units')">Section/Units</a>
        <a href="#" onclick="loadMain('documents')">Documents</a>
        <a href="#" onclick="loadMain('track')">Track Document</a>
        <a href="#" onclick="loadMain('archive')">Archive</a>
        <a href="#" onclick="loadMain('report')">Reports</a>
    </div>

    <!--Dashboard Content(Start) -->
    <div id="main">
    </div>
    <!--Dashboard Content(End)-->

    <script src="main.js"></script>
    <script src="functions/section_units.js"></script>
    <script src="functions/documents.js"></script>
</body>

</html>