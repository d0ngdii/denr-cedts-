<?php
// Database connection
$db = require_once 'db_connection.php';

// Collect and sanitize form data
$fullName = trim($db->real_escape_string($_POST['fullName'] ?? ''));
$mobileNumber = trim($db->real_escape_string($_POST['mobileNumber'] ?? ''));
$email = trim($db->real_escape_string($_POST['email'] ?? ''));
$password = $_POST['password'] ?? ''; // Don't escape or trim password
$position = trim($db->real_escape_string($_POST['position'] ?? ''));

// Validate input
if (empty($fullName) || empty($mobileNumber) || empty($email) || empty($password) || empty($position)) {
    die(json_encode(['success' => false, 'message' => 'All fields are required']));
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die(json_encode(['success' => false, 'message' => 'Invalid email format']));
}

// Validate position
$validPositions = [
    'CENR Office', 
    'Admin UNIT', 
    'Records Section', 
    'CDS', 
    'RPS', 
    'MES'
];

if (!in_array($position, $validPositions)) {
    die(json_encode(['success' => false, 'message' => 'Invalid position']));
}

// Hash the password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Verify the hash was generated successfully
if ($hashedPassword === false) {
    die(json_encode(['success' => false, 'message' => 'Password hashing failed']));
}

// Prepare and bind
$stmt = $db->prepare("INSERT INTO users (name, contact, email, password, position) VALUES (?, ?, ?, ?, ?)");
if ($stmt === false) {
    die(json_encode(['success' => false, 'message' => 'Prepare failed: ' . $db->error]));
}

$stmt->bind_param("sssss", $fullName, $mobileNumber, $email, $hashedPassword, $position);

// Execute the statement
if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'User registered successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Registration failed: ' . $stmt->error]);
}

$stmt->close();
$db->close();
?>