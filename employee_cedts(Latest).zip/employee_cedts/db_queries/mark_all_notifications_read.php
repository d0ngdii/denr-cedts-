<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include the database connection
$conn = require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sql = "UPDATE notifications SET is_read = 1 WHERE is_read = 0";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        die(json_encode(["error" => "Prepare failed: " . $conn->error]));
    }
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to mark all notifications as read: ' . $stmt->error]);
    }

    $stmt->close();
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
}

// Close connection
$conn->close();
?>