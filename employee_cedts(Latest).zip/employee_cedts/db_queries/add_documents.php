<?php
// Set the content type to JSON for API-like responses
header('Content-Type: application/json');

try {
    // Database connection
    $db = require_once 'db_connection.php';

    // Retrieve and sanitize POST data
    $appointment_number = filter_input(INPUT_POST, 'appointment_number', FILTER_SANITIZE_STRING) ?? '';
    $sender = filter_input(INPUT_POST, 'sender', FILTER_SANITIZE_STRING) ?? '';
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL) ?? '';
    $contact_number = filter_input(INPUT_POST, 'contact_number', FILTER_SANITIZE_STRING) ?? '';
    $document_type = filter_input(INPUT_POST, 'document_type', FILTER_SANITIZE_STRING) ?? '';
    $purpose = filter_input(INPUT_POST, 'purpose', FILTER_SANITIZE_STRING) ?? '';
    $paid = filter_input(INPUT_POST, 'paid', FILTER_SANITIZE_STRING) ?? '';
    $subject = filter_input(INPUT_POST, 'subject', FILTER_SANITIZE_STRING) ?? 'N/A';
    $subject = ($subject !== false && $subject !== null && trim($subject) !== '') ? $subject : 'N/A'; //Set the subject as "N/A" if no inputs
    $date_received = filter_input(INPUT_POST, 'date_received', FILTER_SANITIZE_STRING) ?? date('Y-m-d H:i:s');
    $status = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_STRING) ?? '';
    $appointment_type = filter_input(INPUT_POST, 'appointment_type', FILTER_SANITIZE_STRING) ?? '';
    $appointment_date = filter_input(INPUT_POST, 'appointment_date', FILTER_SANITIZE_STRING) ?? '';

    // Calculate the due date (8-10 days from now)
    $days_to_add = rand(8, 10);
    $due_date = date('Y-m-d H:i:s', strtotime("+$days_to_add days"));

    // Handle file upload
    $file_content = null;
    $file_name = null;
    if (!empty($_FILES['files']['name'][0])) {
        $file_name = $_FILES['files']['name'][0];
        $file_content = file_get_contents($_FILES['files']['tmp_name'][0]);
    }

    // Prepare and execute the SQL statement to insert the document
    $stmt = $db->prepare("INSERT INTO documents (appointment_number, sender, email, contact_number, document_type, purpose, paid, subject, date_received, status, appointment_type, appointment_date, due_date, file_content, file_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    if (!$stmt) {
        throw new Exception("Prepare failed: " . $db->error);
    }

    $null = NULL;
    $stmt->bind_param("sssssssssssssbs", $appointment_number, $sender, $email, $contact_number, $document_type, $purpose, $paid, $subject, $date_received, $status, $appointment_type, $appointment_date, $due_date, $null, $file_name);

    if ($file_content !== null) {
        $stmt->send_long_data(13, $file_content);
    }

    if (!$stmt->execute()) {
        throw new Exception("Execute failed: " . $stmt->error);
    }

    $document_id = $stmt->insert_id;
    $stmt->close();

    // Insert notification
    $notification_title = "{$document_type}";
    $notification_message = "Sender: {$sender}. Date Received: {$date_received}. Due Date: {$due_date}";
    insertNotification($db, $notification_title, $notification_message, "New Document", $document_id);

    // Check for approaching due dates
    checkApproachingDueDates($db);

    echo json_encode(['success' => true, 'message' => 'Document added successfully', 'due_date' => $due_date]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} finally {
    if (isset($db) && $db instanceof mysqli) {
        $db->close();
    }
}



/**
 * Insert a new notification into the database
 * 
 * @param mysqli $db Database connection
 * @param string $title Notification title
 * @param string $message Notification message
 * @param string $type Notification type
 * @param int $document_id Document ID
 * @return void
 */
function insertNotification($db, $title, $message, $type, $document_id)
{
    $stmt = $db->prepare("INSERT INTO notifications (title, message, type, document_id, created_at, is_read) VALUES (?, ?, ?, ?, NOW(), 0)");

    if (!$stmt) {
        error_log("Prepare failed: " . $db->error);
        return;
    }

    $stmt->bind_param("sssi", $title, $message, $type, $document_id);

    if (!$stmt->execute()) {
        error_log("Execute failed: " . $stmt->error);
    }

    $stmt->close();
}

function checkApproachingDueDates($db)
{
    $three_days_from_now = date('Y-m-d', strtotime('+3 days'));

    $stmt = $db->prepare("SELECT document_id, document_type, sender, due_date FROM documents WHERE DATE(due_date) = ?");
    if (!$stmt) {
        error_log("Prepare failed: " . $db->error);
        return;
    }

    $stmt->bind_param("s", $three_days_from_now);

    if (!$stmt->execute()) {
        error_log("Execute failed: " . $stmt->error);
        $stmt->close();
        return;
    }

    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $notification_title = "Due Date Approaching: {$row['document_type']}";
        $notification_message = "Document from {$row['sender']} is due in 3 days (on {$row['due_date']}).";
        insertNotification($db, $notification_title, $notification_message, "Due Date Approaching", $row['id']);
    }

    $stmt->close();
}
