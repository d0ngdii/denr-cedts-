<?php
// db_connection.php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "denr_cedts";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Connection failed: " . $conn->connect_error]));
}

return $conn;
?>