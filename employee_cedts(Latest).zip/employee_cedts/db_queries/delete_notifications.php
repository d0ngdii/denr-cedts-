<?php
header('Content-Type: application/json');

// Include the database connection
$conn = require_once 'db_connection.php';

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (isset($input['ids']) && is_array($input['ids'])) {
    $ids = array_map('intval', $input['ids']);

    if (empty($ids)) {
        echo json_encode(['success' => false, 'message' => 'No valid IDs provided']);
        exit;
    }

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $sql = "DELETE FROM notifications WHERE id IN ($placeholders)";
    $stmt = $conn->prepare($sql);
    
    if ($stmt) {
        $types = str_repeat('i', count($ids));
        $stmt->bind_param($types, ...$ids);
        
        if ($stmt->execute()) {
            $affected_rows = $stmt->affected_rows;
            if ($affected_rows > 0) {
                echo json_encode(['success' => true, 'message' => $affected_rows . ' notification(s) deleted successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'No notifications found with the given IDs']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to execute the query: ' . $stmt->error]);
        }

        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to prepare the statement: ' . $conn->error]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid or missing IDs']);
}

// Close connection
$conn->close();
?>