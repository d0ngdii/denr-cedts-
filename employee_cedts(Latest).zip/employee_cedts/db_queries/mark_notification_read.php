<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include the database connection
$conn = require_once 'db_connection.php';

// Check if the request method is POST and id is set
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['id'])) {
    $notification_id = intval($_GET['id']);

    // Prepare and execute the update query
    $sql = "UPDATE notifications SET is_read = 1 WHERE id = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("i", $notification_id);

        if ($stmt->execute()) {
            // Check if any rows were affected
            if ($stmt->affected_rows > 0) {
                echo json_encode(['success' => true, 'message' => 'Notification marked as read']);
            } else {
                echo json_encode(['success' => false, 'message' => 'No notification found with the given ID']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to execute the query: ' . $stmt->error]);
        }

        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to prepare the statement: ' . $conn->error]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method or missing ID']);
}

// Close connection
$conn->close();
?>