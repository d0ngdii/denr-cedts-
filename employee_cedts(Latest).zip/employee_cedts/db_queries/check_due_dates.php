<?php
// Include the database connection
$conn = require_once 'db_connection.php';

function insertNotification($conn, $title, $message, $type, $document_id = null)
{
    $sql = "INSERT INTO notifications (title, message, type, document_id) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $title, $message, $type, $document_id);

    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}

function checkDueDates($conn)
{
    $sql = "SELECT id, title FROM documents WHERE due_date = DATE_ADD(CURDATE(), INTERVAL 3 DAY)";
    $result = $conn->query($sql);

    while ($row = $result->fetch_assoc()) {
        $title = "Due Date Approaching";
        $message = "Document '{$row['title']}' is due in 3 days.";
        insertNotification($conn, $title, $message, "due_date", $row['id']);
    }
}

// Run the function
checkDueDates($conn);

// Close the database connection
$conn->close();

echo "Due date check completed.";
?>