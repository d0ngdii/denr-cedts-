<?php
// Database connection
$db = require_once 'db_connection.php';

// Fetch documents from the database
function getDocuments($db)
{
    $stmt = $db->prepare("SELECT appointment_number, email, contact_number, purpose, paid, appointment_date, date_received FROM documents WHERE sender = ?");
    $sender = isset($_GET['sender']) ? $_GET['sender'] : '';
    $stmt->bind_param("s", $sender);
    $stmt->execute();
    $result = $stmt->get_result();

    $documents = [];
    while ($row = $result->fetch_assoc()) {
        $documents[] = $row;
    }

    return json_encode($documents);
}

// Output JSON response
header('Content-Type: application/json');
echo getDocuments($db);

$db->close();
