<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "denr_cedts";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

// Get the limit from a query parameter, defaulting to 50 if not specified
$limit = isset($_GET['limit']) ? intval($_GET['limit']) : 50;

// Ensure the limit is between 1 and 1000 for safety
$limit = max(1, min($limit, 1000));

$sql = "SELECT id, title, message, type, document_id, created_at, is_read FROM notifications ORDER BY created_at DESC LIMIT ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $limit);
$stmt->execute();
$result = $stmt->get_result();

$notifications = [];

if ($result === false) {
    die(json_encode(["error" => "Query failed: " . $conn->error]));
}

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
}

// Close connection
$conn->close();

// Send JSON response
header('Content-Type: application/json');
echo json_encode($notifications);
