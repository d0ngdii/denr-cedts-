<?php
// load_content.php
if (isset($_GET['section'])) {
    $section = $_GET['section'];
    
    switch ($section) {
        case 'dashboard':
            include 'sideNav/dashboard.php';
            break;
        case 'units':
            include 'sideNav/section_units.php';
            break;
        case 'documents':
            include 'sideNav/documents.php';
            break;
        case 'track':
            include 'sideNav/track_documents.php';
            break;
        case 'archive':
            include 'sideNav/archive.php';
            break;
        case 'report':
            include 'sideNav/report.php';
            break;
        default:
            echo "<h2>404 - Page Not Found</h2><p>The requested section does not exist.</p>";
    }
} else {
    echo "<h2>Error</h2><p>No section specified.</p>";
}