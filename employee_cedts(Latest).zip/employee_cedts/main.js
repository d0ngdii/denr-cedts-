// Load dashboard by default when the DOM is fully loaded
document.addEventListener("DOMContentLoaded", function () {
  loadMain("dashboard");
  updateTime();
  fetchNotifications();
});

// Load main content based on the selected section
function loadMain(section) {
  console.log("Loading section:", section);
  fetch(`load_content.php?section=${section}`)
    .then((response) => response.text())
    .then((html) => {
      console.log("Received HTML:", html);
      document.getElementById("main").innerHTML = html;
      if (section === "units") {
        console.log("Setting up units listeners");
        setupSectionUnitListeners();
      } else if (section === "documents") {
        console.log("Setting up document listeners");
        setupDocumentListeners();
      }
    })
    .catch((error) => console.error("Error:", error));
}

// Toggle the Side Navigation Menu
function toggleNav(x) {
  x.classList.toggle("change");
  var sidenav = document.getElementById("mySidenav");
  var main = document.getElementById("main");

  if (sidenav.style.width === "200px") {
    sidenav.style.width = "0";
    main.style.marginLeft = "0";
  } else {
    sidenav.style.width = "200px";
    main.style.marginLeft = "200px";
  }
}

// Function to update the current time
function updateTime() {
  const now = new Date();
  const formattedTime = now
    .toLocaleString("en-PH", {
      timeZone: "Asia/Manila",
      hour12: false,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    })
    .replace(",", "")
    .replace(" ", " ");

  document.getElementById(
    "current-time"
  ).textContent = `${formattedTime} Philippine Standard Time`;
}

// Update time every second
setInterval(updateTime, 1000);

// Toggle Notifications
function toggleNotifications() {
  const popup = document.getElementById("notificationPopup");
  const overlay = document.getElementById("overlay");
  if (popup.style.display === "none" || popup.style.display === "") {
      popup.style.display = "block";
      overlay.style.display = "block";
      fetchNotifications();
  } else {
      popup.style.display = "none";
      overlay.style.display = "none";
  }
}

// Function to fetch notifications and shows it
function fetchNotifications(limit = 50) {
  fetch(`db_queries/get_notifications.php?limit=${limit}`)
      .then((response) => response.ok ? response.json() : Promise.reject("Network response was not ok"))
      .then((data) => {
          updateNotificationCount(data);
          updateNotificationTable(data);
      })
      .catch((error) => {
          console.error("Error fetching notifications:", error);
          document.getElementById("notificationBody").innerHTML = "<tr><td colspan='6'>Error loading notifications</td></tr>";
      });
}

function updateNotificationCount(notifications) {
  const count = notifications.filter(n => !n.is_read).length;
  const notificationCount = document.getElementById("notificationCount");
  notificationCount.textContent = count;
  notificationCount.style.display = count ? "inline" : "none";
}

function updateNotificationTable(notifications) {
  const tbody = document.getElementById('notificationBody');
  tbody.innerHTML = '';
  notifications.forEach(notification => {
      const row = `
          <tr class="${notification.is_read ? '' : 'new-notification'}">
              <td><input type="checkbox" class="notification-checkbox" data-id="${notification.id}"></td>
              <td>${notification.title}</td>
              <td>${notification.message}</td>
              <td>${notification.type}</td>
              <td>${new Date(notification.created_at).toLocaleString()}</td>
              <td>
                  ${notification.is_read ? '<span class="check-icon">✓</span>' : '<span class="x-icon">X</span>'}
              </td>
          </tr>
      `;
      tbody.innerHTML += row;
  });
}
// Mark a Notification as Read
function markAsRead(id) {
    fetch(`db_queries/mark_notification_read.php?id=${id}`, { method: 'POST' })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                console.log('Notification marked as read:', data.message);
                fetchNotifications();
            } else {
                console.error('Failed to mark notification as read:', data.message);
            }
        })
        .catch(error => {
            console.error('Error marking notification as read:', error);
        });
}
// Mark all Notifications as Read
function markAllAsRead() {
  fetch(`db_queries/mark_all_notifications_read.php`, { method: 'POST' })
      .then(response => response.json())
      .then(data => {
          if (data.success) {
              fetchNotifications();
          } else {
              console.error('Failed to mark all notifications as read');
          }
      })
      .catch(error => console.error('Error:', error));
}
// Delete selected Notifications
function deleteSelected() {
  const checkboxes = document.querySelectorAll('.notification-checkbox:checked');
  const idsToDelete = Array.from(checkboxes).map(cb => parseInt(cb.getAttribute('data-id'), 10));
  
  if (idsToDelete.length === 0) {
    alert('No notifications selected for deletion');
    return;
  }

  fetch('db_queries/delete_notifications.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ ids: idsToDelete })
  })
  .then(response => {
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    return response.json();
  })
  .then(data => {
    if (data.success) {
      alert(data.message);
      fetchNotifications(); // Assuming this function refreshes the notification list
    } else {
      throw new Error(data.message);
    }
  })
  .catch(error => {
    console.error('Error:', error);
    alert('An error occurred: ' + error.message);
  });
}
// Toggle to select all Notifications
function toggleSelectAll() {
  const selectAllCheckbox = document.getElementById('selectAll');
  const checkboxes = document.querySelectorAll('.notification-checkbox');
  checkboxes.forEach(cb => cb.checked = selectAllCheckbox.checked);
}

// Fetch notifications every 60 seconds
setInterval(fetchNotifications, 60000);

// Initial fetch of notifications
fetchNotifications();

// Add event listener to mark notifications as read when clicked
document.getElementById('notificationBody').addEventListener('click', function(e) {
  if (e.target.tagName === 'TD') {
      const row = e.target.closest('tr');
      const id = row.querySelector('.notification-checkbox').getAttribute('data-id');
      markAsRead(id);
  }
});

// Close the dropdown if the user clicks outside of it
window.onclick = function (event) {
  if (!event.target.matches(".btn1")) {
    document
      .querySelectorAll(".dropdown-content.show")
      .forEach((dropdown) => dropdown.classList.remove("show"));
  }
};
