// Wait for the DOM to be fully loaded before executing any scripts
document.addEventListener("DOMContentLoaded", function () {
  setupSectionUnitListeners();
  setupSearchFunctionality();
});

//-----------------------ADDS A NEW USER ON DATABASE----------------------------
// Function to set up listeners for the account form
function setupSectionUnitListeners() {
  const addAccountForm = document.getElementById("addAccountForm");
  if (addAccountForm) {
    addAccountForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const formData = new FormData(this);
      fetch("db_queries/add_user.php", {
        method: "POST",
        body: formData,
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            alert("User added successfully");
            secCloseModal();
            fetchUsers(); // Refresh the user list
          } else {
            alert("Error adding user: " + data.message);
          }
        })
        .catch((error) => console.error("Error:", error));
    });
  }
  // Set up search functionality
  setupSearchFunctionality();
}

//-----------------------USERS SEARCH FUNCTIONALITY----------------------------
// Function to set up the search functionality
function setupSearchFunctionality() {
  const searchInput = document.getElementById("secsearchInput");
  if (searchInput) {
    searchInput.addEventListener("input", function () {
      searchUsers();
    });
  }
}

// Function to search users and filter the table
function searchUsers() {
  input = document.getElementById("secsearchInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("usertable");
  tr = table.getElementsByTagName("tr");

  for (i = 1; i < tr.length; i++) {
    var display = "none";
    for (j = 0; j < tr[i].cells.length; j++) {
      td = tr[i].cells[j];
      if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          display = "";
          break;
        }
      }
    }
    tr[i].style.display = display;
  }
}

//-----------------------OPENS NEW USER MODAL----------------------------
// Function to open the modal
function secOpenModal() {
  document.getElementById("addAccountModal").style.display = "block";
  document.getElementById("sectionModalOverlay").style.display = "block";
}

//-----------------------CLOSES NEW USER MODAL----------------------------
// Function to close the modal
function secCloseModal() {
  document.getElementById("addAccountModal").style.display = "none";
  document.getElementById("sectionModalOverlay").style.display = "none";
}

// Function to toggle password visibility
function togglePassword() {
  const passwordInput = document.getElementById("password");
  const type =
    passwordInput.getAttribute("type") === "password" ? "text" : "password";
  passwordInput.setAttribute("type", type);
}
