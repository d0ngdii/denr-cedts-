// Wait for the DOM to be fully loaded before executing any scripts
document.addEventListener("DOMContentLoaded", function () {
  setupDocumentListeners();
  setupDocSearchFunctionality();
  // initializeEventListeners();
  // setupAppointmentForm();
});

//--------------------------ADD A DOCUMENT ON DATABASE-----------------------------
// Set up listeners for the document form
function setupDocumentListeners() {
  const addDocumentForm = document.getElementById("addDocumentForm");
  if (addDocumentForm) {
    addDocumentForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const formData = new FormData(this);

        fetch("db_queries/add_documents.php", {
        method: "POST",
        body: formData,
      })
        .then((response) => {
          console.log("Response received:", response); // Debugging line
          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
          }
          // Clone the response before reading it
          const responseClone = response.clone();
          return response.json().catch(() => {
            console.warn("Response is not JSON, trying to read as text");
            return responseClone.text().then((text) => {
              console.error("Raw response:", text);
              throw new Error(`Expected JSON, got ${text}`);
            });
          });
        })
        .then((data) => {
          if (data.success) {
            alert("Documents added successfully");
            docCloseModal();
          } else {
            alert(
              "Error adding documents: " + (data.message || "Unknown error")
            );
          }
        })
        .catch((error) => {
          console.error("Error:", error);
          alert(`Error adding documents: ${error.message}`);
        });
    });
  }
  // Set up search functionality
  setupDocSearchFunctionality();
  // Add click listeners to table rows
  addRowClickListeners();
}

//--------------------------OPEN ADD A DOCUMENT MODAL-----------------------------
// Function to open the modal for adding a new document
function docOpenModal() {
  const modal = document.getElementById("addDocumentModal");
  const overlay = document.getElementById("documentModalOverlay");
  if (modal && overlay) {
    modal.style.display = "block";
    overlay.style.display = "block";
  }
  //Function to automatically generate an appointment number
  generateAppointmentNumber();

  // Set today's date when the form opens
  const today = new Date();
  const dateInput = document.getElementById("date");
  if (dateInput) {
    dateInput.value = formatDate(today);
  }
}

// Function to format date as MM/DD/YYYY
function formatDate(date) {
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const year = date.getFullYear();
  return `${month}/${day}/${year}`;
}
// Function to automatically generate an appointment number
function generateAppointmentNumber() {
  const chars =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let appointmentNumber = "";
  for (let i = 0; i < 10; i++) {
    appointmentNumber += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  document.getElementById("appointment_number").value = appointmentNumber;
}

//--------------------------CLOSES A DOCUMENT MODAL-----------------------------
// Function to close the modal for adding a new document
function docCloseModal() {
  const modal = document.getElementById("addDocumentModal");
  const overlay = document.getElementById("documentModalOverlay");
  if (modal && overlay) {
    modal.style.display = "none";
    overlay.style.display = "none";
  }
}

//--------------------------SEARCH FUNCTIONALITY FOR DOCUMENTS TABLE-----------------------------
// Function to set up the search functionality
function setupDocSearchFunctionality() {
  const searchInput = document.getElementById("documentSearchInput");
  if (searchInput) {
    searchInput.addEventListener("input", function () {
      searchDocuments();
    });
  }
}

// Function to search documents and filter the table
function searchDocuments() {
  var input, filter, table, tr, td, i, j, txtValue;
  input = document.getElementById("documentSearchInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("documentTable");
  tr = table.getElementsByTagName("tr");

  for (i = 1; i < tr.length; i++) {
    var display = "none";
    for (j = 0; j < tr[i].cells.length; j++) {
      td = tr[i].cells[j];
      if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          display = "";
          break;
        }
      }
    }
    tr[i].style.display = display;
  }
}

//--------------------------DOCUMENTS TABLE ROW CLICK LISTENER-----------------------------
// Function to add click event listeners to each table row
function addRowClickListeners() {
  const rows = document.querySelectorAll("#documentTableBody tr");
  if (rows && rows.length > 0) {
    rows.forEach((row) => {
      row.addEventListener("click", function () {
        // Remove 'selected' class from all rows and add to clicked row
        rows.forEach((r) => r.classList.remove("selected"));
        this.classList.add("selected");

        const sender = this.cells[0].textContent;

        // Make AJAX request
        fetch(
          `db_queries/view_documents.php?sender=${encodeURIComponent(
            sender
          )}`
        )
          .then((response) => response.json())
          .then((data) => {
            if (data && data.length > 0) {
              const rowData = {
                appointmentNumber: data[0].appointment_number || "N/A",
                sender: sender,
                email: data[0].email || "N/A",
                contactNumber: data[0].contact_number || "N/A",
                status: this.cells[4].textContent,
                documentType: this.cells[1].textContent,
                purpose: data[0].purpose || "N/A",
                paid: data[0].paid ? "Yes" : "No",
                appointmentDate: data[0].appointment_date || "N/A",
                dateReceived: data[0].date_received || "N/A",
              };
              openPopup(rowData);
            } else {
              console.error("No data received from server");
            }
          })
          .catch((error) => {
            console.error("Error:", error);
            // Use table data in case of error
            const rowData = {
              appointmentNumber: "N/A",
              sender: sender,
              email: "N/A",
              contactNumber: "N/A",
              status: this.cells[4].textContent,
              documentType: this.cells[1].textContent,
              purpose: "N/A",
              paid: "N/A",
              appointmentDate: "N/A",
              dateReceived: "N/A",
            };
            openPopup(rowData);
          });
      });
    });
  } else {
    console.log("No rows found in the document table");
  }
}

// Open the popup with document details
function openPopup(rowData) {
  const popupOverlay = document.getElementById("popupOverlay");
  const popupForm = document.getElementById("popupForm");

  if (popupOverlay && popupForm) {
    popupOverlay.style.display = "block";
    popupForm.style.display = "block";

    // Populate the form with data
    document.getElementById("appointmentNumberDisplay").textContent =
      rowData.appointmentNumber;
    document.getElementById("senderName").textContent = rowData.sender;
    document.getElementById("senderEmail").textContent = rowData.email;
    document.getElementById("contactNumber").textContent =
      rowData.contactNumber;
    document.getElementById("status").textContent = rowData.status;
    document.getElementById("documentType").textContent = rowData.documentType;
    document.getElementById("purpose").textContent = rowData.purpose;
    document.getElementById("paid").textContent = rowData.paid;
    document.getElementById("dateReceived").textContent = rowData.dateReceived;
    document.getElementById("appointmentDate").textContent =
      rowData.appointmentDate;

    // Populate file list
    // const fileList = document.getElementById("fileList");
    // if (fileList) {
    //   fileList.innerHTML = "";
    //   rowData.files.forEach((file) => {
    //     const fileLink = document.createElement("a");
    //     fileLink.href = "#";
    //     fileLink.className = "file-link";
    //     fileLink.textContent = file;
    //     fileLink.onclick = () => viewFile(file);
    //     fileList.appendChild(fileLink);
    //   });
    // }
  }
}

//--------------------------CLOSE VIEWED DOCUMENTS TABLE ROW CLICKED-----------------------------
// Function to close the popup
function docpClosePopup() {
  const popupOverlay = document.getElementById("popupOverlay");
  const popupForm = document.getElementById("popupForm");

  if (popupOverlay && popupForm) {
    popupOverlay.style.display = "none";
    popupForm.style.display = "none";
    // closeAppointmentPopup(); // Close appointment popup when the document popup is closed
    // closeOrderPaymentForm(); // Ensure order payment form is closed
  }
}

// Function to view a file (placeholder)
function viewFile(filename) {
  alert(`Viewing file: ${filename}`);
}

//--------------------------(*WORK ON PROGRESS)-----------------------------
// Function to proceed to next step (modified)
function docpNextStep() {
  const selectedRow = document.querySelector("#documentTableBody tr.selected");
  if (selectedRow) {
    const statusCell = selectedRow.cells[4]; // Assuming status is in the 5th column (index 4)
    if (
      statusCell &&
      statusCell.textContent.trim().toUpperCase() === "PENDING"
    ) {
      docpClosePopup(); // Close the document popup first
      openAppointmentPopup(); // Then open the appointment popup
    } else {
      alert("Appointments can only be scheduled for PENDING status documents.");
    }
  } else {
    alert("Please select a document first.");
  }
}

// Function to open the confirmation of appointment popup
function openAppointmentPopup() {
  const overlay = document.getElementById("appointmentPopupOverlay");
  const form = document.getElementById("appointmentPopupForm");
  if (overlay && form) {
    overlay.style.display = "block";
    form.style.display = "block";
  }
}

// Function to close the confirmation of appointment popup
function closeAppointmentPopup() {
  const overlay = document.getElementById("appointmentPopupOverlay");
  const form = document.getElementById("appointmentPopupForm");
  if (overlay && form) {
    overlay.style.display = "none";
    form.style.display = "none";
  }
}